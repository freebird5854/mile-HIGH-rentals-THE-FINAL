
MILE HIGH RENTALS — REDEPLOY GUIDE

1) Delete your current Netlify site (optional, if you want a clean start).
2) Go to https://app.netlify.com → Add new site → Deploy manually.
3) Upload this ZIP directly (no need to extract).
4) Wait for Netlify to finish publishing.
5) Attach your custom domain in Domain Settings.
6) Visit your site → you should see all listings, carousels, and Apply Now buttons working.

